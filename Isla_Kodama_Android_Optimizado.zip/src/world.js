import * as THREE from 'three';
export function createWorld(scene){
 const group=new THREE.Group();scene.add(group);
 const sand=new THREE.MeshStandardMaterial({color:0xc9b78b,roughness:1});
 const grass=new THREE.MeshStandardMaterial({color:0x587c50,roughness:1});
 const darkGrass=new THREE.MeshStandardMaterial({color:0x3e6546,roughness:1});
 const bark=new THREE.MeshStandardMaterial({color:0x604a35,roughness:1});
 const leafMats=[0x426d4d,0x547e54,0x6c8a59,0x365d47].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
 const rockMat=new THREE.MeshStandardMaterial({color:0x777d75,roughness:1});
 const waterMat=new THREE.MeshStandardMaterial({color:0x477f83,roughness:.38,metalness:.05});
 const island=new THREE.Mesh(new THREE.SphereGeometry(1,32,20),grass);island.scale.set(36,5,36);island.position.y=-4.7;group.add(island);
 const beach=new THREE.Mesh(new THREE.SphereGeometry(1,32,16),sand);beach.scale.set(36.3,4.2,36.3);beach.position.y=-5.0;group.add(beach);
 const sea=new THREE.Mesh(new THREE.PlaneGeometry(500,500,1,1),waterMat);sea.rotation.x=-Math.PI/2;sea.position.y=-1.2;group.add(sea);
 const groundY=(x,z)=>{const r=Math.sqrt(x*x+z*z);return Math.max(-.2,2.0-r*.045)+Math.sin(x*.14)*.22+Math.cos(z*.13)*.2;};
 const resources=[];const rand=(a,b)=>a+Math.random()*(b-a);
 // Low-poly foliage and resource objects: small fixed count, shared materials/geometries.
 const trunkGeo=new THREE.CylinderGeometry(.18,.28,2.3,6);
 const crownGeo=new THREE.IcosahedronGeometry(1.25,1);
 const rockGeo=new THREE.DodecahedronGeometry(.65,0);
 const bushGeo=new THREE.IcosahedronGeometry(.55,1);
 function addTree(x,z,resource=true){const y=groundY(x,z);const tree=new THREE.Group();tree.position.set(x,y,z);const tr=new THREE.Mesh(trunkGeo,bark);tr.position.y=1;tree.add(tr);const crown=new THREE.Mesh(crownGeo,leafMats[Math.floor(Math.random()*leafMats.length)]);crown.position.y=2.55;crown.scale.set(1.1,1.15,1);tree.add(crown);group.add(tree);if(resource){tree.userData={kind:'tree',active:true};resources.push(tree);}}
 function addRock(x,z){const o=new THREE.Mesh(rockGeo,rockMat);o.position.set(x,groundY(x,z)+.35,z);o.rotation.set(rand(0,1),rand(0,3),rand(0,1));o.scale.set(1.2,.8,1);group.add(o);o.userData={kind:'rock',active:true};resources.push(o);}
 function addBush(x,z){const o=new THREE.Mesh(bushGeo,new THREE.MeshStandardMaterial({color:0x64824c,roughness:1}));o.position.set(x,groundY(x,z)+.45,z);o.scale.set(1,.8,1);group.add(o);o.userData={kind:'bush',active:true};resources.push(o);}
 for(let i=0;i<58;i++){const a=rand(0,Math.PI*2),r=rand(9,31),x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.hypot(x,z)>8)addTree(x,z,i<18);}
 for(let i=0;i<18;i++){const a=rand(0,Math.PI*2),r=rand(5,30);addRock(Math.cos(a)*r,Math.sin(a)*r);}
 for(let i=0;i<18;i++){const a=rand(0,Math.PI*2),r=rand(5,28);addBush(Math.cos(a)*r,Math.sin(a)*r);}
 // Distant tree silhouettes are decorative and not interactive.
 for(let i=0;i<24;i++){const a=rand(0,6.28),r=rand(14,32),x=Math.cos(a)*r,z=Math.sin(a)*r;addTree(x,z,false);}
 const animals=[];
 const animalMat=new THREE.MeshStandardMaterial({color:0x987d5a,roughness:1});
 const animalGeo=new THREE.SphereGeometry(.38,8,6);
 for(let i=0;i<7;i++){const a=new THREE.Mesh(animalGeo,animalMat);a.scale.set(1.35,.8,.7);a.position.set(rand(-23,23),groundY(0,0)+.2,rand(-23,23));group.add(a);animals.push({mesh:a,phase:rand(0,6)});}
 function addHut(pos){const hut=new THREE.Group();const wood=new THREE.MeshStandardMaterial({color:0x70563b,roughness:1});const roofmat=new THREE.MeshStandardMaterial({color:0x66513a,roughness:1});const base=new THREE.Mesh(new THREE.BoxGeometry(3,1.7,2.6),wood);base.position.y=.9;hut.add(base);const roof=new THREE.Mesh(new THREE.ConeGeometry(2.35,1.35,4),roofmat);roof.position.y=2.35;roof.rotation.y=Math.PI/4;hut.add(roof);hut.position.set(pos.x,groundY(pos.x,pos.z),pos.z-2.8);group.add(hut);}
 function addCampfire(pos){const fire=new THREE.Group();const stone=new THREE.Mesh(rockGeo,rockMat);stone.scale.set(1.1,.35,1.1);stone.position.y=.15;fire.add(stone);const flame=new THREE.Mesh(new THREE.ConeGeometry(.3,.9,6),new THREE.MeshBasicMaterial({color:0xff9a42}));flame.position.y=.75;fire.add(flame);fire.position.set(pos.x,groundY(pos.x,pos.z),pos.z-1.5);group.add(fire);}
 function update(dt,t){sea.position.y=-1.2+Math.sin(t*.5)*.06;animals.forEach((a,i)=>{a.mesh.position.x+=Math.sin(t*.4+a.phase)*dt*.35;a.mesh.position.z+=Math.cos(t*.35+a.phase)*dt*.25;a.mesh.position.y=groundY(a.mesh.position.x,a.mesh.position.z)+.35;});}
 return {resources,groundY,addHut,addCampfire,update};
}