import * as THREE from 'three';
import { createWorld } from './world.js';

const mount = document.querySelector('#game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bb8a7);
scene.fog = new THREE.Fog(0x9bb8a7, 38, 105);
const camera = new THREE.PerspectiveCamera(62, innerWidth/innerHeight, .1, 180);
const renderer = new THREE.WebGLRenderer({antialias:false, powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.35));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
mount.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xe4f1dc,0x56664d,2.0); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe6bb,1.35); sun.position.set(-25,38,18); scene.add(sun);
const world = createWorld(scene);

const player = new THREE.Group();
const bodyMat = new THREE.MeshStandardMaterial({color:0x344b42,roughness:1});
const skinMat = new THREE.MeshStandardMaterial({color:0xc58e68,roughness:1});
const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.28,.55,3,6),bodyMat); torso.position.y=.88; player.add(torso);
const head = new THREE.Mesh(new THREE.SphereGeometry(.2,8,6),skinMat); head.position.y=1.42; player.add(head);
const legs = new THREE.Mesh(new THREE.CapsuleGeometry(.11,.42,2,5),bodyMat); legs.position.set(0,.32,0); player.add(legs);
player.position.set(0,world.groundY(0,7),7); scene.add(player);

const state={wood:0,stone:0,fiber:0,berries:0,health:100,hunger:100,stamina:100,day:1,season:0,elapsed:0, built:false, survivors:0, yaw:0, pitch:-.16};
const seasons=['PRIMAVERA','VERANO','OTOÑO','INVIERNO'];
const ui={
 fps:document.querySelector('#fps'),day:document.querySelector('#day'),wood:document.querySelector('#wood'),stone:document.querySelector('#stone'),fiber:document.querySelector('#fiber'),berries:document.querySelector('#berries'),
 health:document.querySelector('#health'),food:document.querySelector('#food'),stamina:document.querySelector('#stamina'),notice:document.querySelector('#notice')
};
function refresh(){ui.wood.textContent=state.wood;ui.stone.textContent=state.stone;ui.fiber.textContent=state.fiber;ui.berries.textContent=state.berries;ui.health.style.width=state.health+'%';ui.food.style.width=state.hunger+'%';ui.stamina.style.width=state.stamina+'%';ui.day.textContent=`DÍA ${state.day} · ${seasons[state.season]}`;}
let noticeTimer;
function notice(t){ui.notice.textContent=t;ui.notice.classList.add('show');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>ui.notice.classList.remove('show'),2400);}
const panel=document.querySelector('#panel'), panelTitle=document.querySelector('#panelTitle'),panelText=document.querySelector('#panelText'),panelButtons=document.querySelector('#panelButtons');
function openPanel(title,desc,items){panelTitle.textContent=title;panelText.textContent=desc;panelButtons.innerHTML='';items.forEach(it=>{const b=document.createElement('button');b.textContent=it.label;b.onclick=()=>{it.run();};panelButtons.appendChild(b)});panel.classList.remove('hidden');}
function closePanel(){panel.classList.add('hidden')}
document.querySelector('#close').onclick=closePanel;
document.querySelector('#menu').onclick=()=>openPanel('Isla Kodama','Sobrevive, reúne recursos y funda tu aldea desde cero.',[
{label:'Continuar',run:closePanel},
{label:'Guardar partida',run:()=>{localStorage.setItem('kodama-save',JSON.stringify(state));notice('Partida guardada en este dispositivo.');closePanel();}},
{label:'Cargar partida',run:()=>{const s=localStorage.getItem('kodama-save');if(s){Object.assign(state,JSON.parse(s));refresh();notice('Partida cargada.');}else notice('Todavía no hay una partida guardada.');closePanel();}}
]);
function buildMenu(){openPanel('Construir','La aldea empieza contigo. Necesitas reunir materiales antes de levantar tu primer refugio.',[
{label:'Refugio sencillo · 8 madera + 5 fibra',run:()=>{if(state.built){notice('Ya construiste tu primer refugio.');return;}if(state.wood>=8&&state.fiber>=5){state.wood-=8;state.fiber-=5;state.built=true;world.addHut(player.position);refresh();notice('Construiste tu primer refugio. La aldea comienza aquí.');closePanel();}else notice('Te faltan materiales. Busca árboles y plantas.');}},
{label:'Fogata · 5 madera + 3 piedra',run:()=>{if(state.wood>=5&&state.stone>=3){state.wood-=5;state.stone-=3;world.addCampfire(player.position);refresh();notice('Fogata construida.');closePanel();}else notice('Necesitas 5 madera y 3 piedra.');}},
{label:'Cerrar',run:closePanel}
]);}
document.querySelector('#build').onclick=buildMenu;
document.querySelector('#eat').onclick=()=>{if(state.berries>0){state.berries--;state.hunger=Math.min(100,state.hunger+28);refresh();notice('Comiste bayas.');}else notice('No tienes comida. Busca arbustos de bayas.');};

const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='e')interact();});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
let joy={x:0,y:0,active:false};const joyEl=document.querySelector('#joystick'),stick=document.querySelector('#stick');
joyEl.addEventListener('pointerdown',e=>{joy.active=true;joyEl.setPointerCapture(e.pointerId);moveJoy(e);});
joyEl.addEventListener('pointermove',e=>{if(joy.active)moveJoy(e);});
function moveJoy(e){const r=joyEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const len=Math.hypot(dx,dy),max=37;if(len>max){dx=dx/len*max;dy=dy/len*max;}joy.x=dx/max;joy.y=dy/max;stick.style.transform=`translate(${dx}px,${dy}px)`;}
function endJoy(){joy.active=false;joy.x=joy.y=0;stick.style.transform='translate(0,0)';}
joyEl.addEventListener('pointerup',endJoy);joyEl.addEventListener('pointercancel',endJoy);
let lookPointer=null,lastX=0,lastY=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.clientX<innerWidth*.34&&e.clientY>innerHeight*.58)return;lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture(e.pointerId);});
renderer.domElement.addEventListener('pointermove',e=>{if(lookPointer!==e.pointerId)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;state.yaw-=dx*.004;state.pitch=Math.max(-.55,Math.min(.2,state.pitch+dy*.0025));});
renderer.domElement.addEventListener('pointerup',()=>lookPointer=null);renderer.domElement.addEventListener('pointercancel',()=>lookPointer=null);

function nearest(){let best=null,bd=3.2;for(const obj of world.resources){if(!obj.userData.active)continue;const d=player.position.distanceTo(obj.position);if(d<bd){bd=d;best=obj;}}return best;}
function interact(){const obj=nearest();if(!obj){notice('No hay recursos cerca. Explora la isla.');return;}const type=obj.userData.kind;if(type==='tree'){state.wood+=2;state.fiber+=1;}if(type==='rock')state.stone+=2;if(type==='bush')state.berries+=2;obj.userData.active=false;obj.visible=false;refresh();notice(type==='tree'?'Recogiste madera y fibra.':type==='rock'?'Recogiste piedra.':'Recogiste bayas.');}
document.querySelector('#interact').onclick=interact;

const clock=new THREE.Clock();let frames=0,fpsTime=0,fpsValue=0;
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);state.elapsed+=dt;frames++;fpsTime+=dt;if(fpsTime>=.5){fpsValue=Math.round(frames/fpsTime);ui.fps.textContent=`FPS ${fpsValue}`;frames=0;fpsTime=0;}
let forward=-(joy.y||((keys.w||keys.arrowup)?1:0)-((keys.s||keys.arrowdown)?1:0));
let side=(joy.x||((keys.d||keys.arrowright)?1:0)-((keys.a||keys.arrowleft)?1:0));
const moving=Math.abs(forward)+Math.abs(side)>.08;
if(moving&&state.stamina>0){const speed=3.1;const dx=(Math.sin(state.yaw)*forward+Math.cos(state.yaw)*side)*speed*dt;const dz=(Math.cos(state.yaw)*forward-Math.sin(state.yaw)*side)*speed*dt;player.position.x+=dx;player.position.z+=dz;player.rotation.y=Math.atan2(dx,dz);state.stamina=Math.max(0,state.stamina-5*dt);}else state.stamina=Math.min(100,state.stamina+8*dt);
player.position.y=world.groundY(player.position.x,player.position.z);
legs.rotation.x=moving?Math.sin(state.elapsed*10)*.35:0;
const target=new THREE.Vector3(player.position.x+Math.sin(state.yaw)*-5,player.position.y+2.8+state.pitch*4,player.position.z+Math.cos(state.yaw)*-5);
camera.position.lerp(target,1-Math.pow(.001,dt));camera.lookAt(player.position.x,player.position.y+1,player.position.z);
state.hunger=Math.max(0,state.hunger-.18*dt);if(state.hunger<=0)state.health=Math.max(0,state.health-.5*dt);
if(state.elapsed>150){state.elapsed=0;state.day++;if(state.day%6===0)state.season=(state.season+1)%4;refresh();}
world.update(dt,state.elapsed);
renderer.render(scene,camera);requestAnimationFrame(()=>{});}
animate();refresh();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setPixelRatio(Math.min(devicePixelRatio,1.35));renderer.setSize(innerWidth,innerHeight);});
setTimeout(()=>{document.querySelector('#loading').style.opacity='0';setTimeout(()=>document.querySelector('#loading').remove(),550);notice('Estás solo en una isla salvaje. Empieza reuniendo recursos.');},700);
